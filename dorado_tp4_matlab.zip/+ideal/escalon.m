function u=escalon(t)
%Genera la funcion escalon: u(t)= 1 si t>=0; 0  si t<0
%Entrada: t-> vector temporal (t) o discreto (n)
%Salida: u-> vector temporal u(t) o discreto u(n)
%-------------------------------------------------------------
  u=(t>=0);
end